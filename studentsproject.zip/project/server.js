const bodyParser = require('body-parser');
const express = require('express');
const { default: mongoose } = require('mongoose');
const student = require('./modals/student');
const app = express();
const methodOverride = require('method-override');

const port = 1000 ;
mongoose.connect('mongodb://localhost:27017/StudentDB', {
    useNewUrlParser : true ,
    useUnifiedTopology : true
})
 
 
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.set('view engine','ejs')
app.use(bodyParser.urlencoded({extended:true}))
app.get('/', async (req,res) =>{
    const students= await student.find()
    res.render ('index', {students})
})

app.post('/save', async (req,res) => {
    const {rollno, name, degree, city} = req.body
     
    const students = new student({rollno, name, degree, city} )
    await students.save()

    res.redirect('/')

})
app.get('/student/:rollno', async (req, res) => {
    const rollno = req.params.rollno;

    try {
        // Find the student with the specified roll number in the database
        const foundStudent = await student.findOne({ rollno });

        if (foundStudent) {
            res.render('studentDetails', { student: foundStudent });
        } else {
            res.status(404).send('Student not found');
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

// DELETE route to delete the student with a specific roll number
app.delete('/student/:rollno', async (req, res) => {
    const rollno = req.params.rollno;

    try {
        // Find and delete the student with the specified roll number in the database
        const deletedStudent = await student.findOneAndDelete({ rollno });

        if (deletedStudent) {
            res.redirect('/');
        } else {
            res.status(404).send('Student not found');
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});
app.get('/edit/:id', async (req, res) => {
    const studentId = req.params.id;

    try {
        // Find the student with the specified ID in the database
        const foundStudent = await student.findById(studentId);

        if (foundStudent) {
            res.render('editStudent', { student: foundStudent });
        } else {
            res.status(404).send('Student not found');
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
})
app.post('/update/:id', async (req, res) => {
    const studentId = req.params.id;
    const { rollno, name, degree, city } = req.body;

    try {
        // Find and update the student with the specified ID in the database
        const updatedStudent = await student.findByIdAndUpdate(studentId, { rollno, name, degree, city }, { new: true });

        if (updatedStudent) {
            res.redirect('/');
        } else {
            res.status(404).send('Student not found');
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});
app.listen(port, ()=> console.log(`server is running on port : ${port}`))